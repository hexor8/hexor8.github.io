#!/bin/bash
# KINETIQ Lite by HExOR_8 - macOS installer. Double-click (right-click > Open the first time). Quit DaVinci Resolve first.
cd "$(dirname "$0")" || exit 1
B="KinetiqLite.ofx.bundle"
if pgrep -x "Resolve" >/dev/null 2>&1; then echo "Please quit DaVinci Resolve first, then run this again."; read -r -p "Press Return to close." _; exit 1; fi
if [ ! -d "$B" ]; then echo "Cannot find $B next to this installer."; read -r -p "Press Return to close." _; exit 1; fi
echo "Installing KINETIQ Lite (your Mac password is needed to write to /Library/OFX/Plugins)..."
sudo mkdir -p /Library/OFX/Plugins || exit 1
sudo rm -rf "/Library/OFX/Plugins/$B"
sudo cp -R "$B" /Library/OFX/Plugins/ || exit 1
sudo chmod -R a+rX "/Library/OFX/Plugins/$B"
sudo xattr -dr com.apple.quarantine "/Library/OFX/Plugins/$B" 2>/dev/null
sudo codesign --force --sign - "/Library/OFX/Plugins/$B" 2>/dev/null   # ad-hoc signature: needed for Apple Silicon code
S="$HOME/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion"
mkdir -p "$S/Templates" "$S/Defaults"
cp "KINETIQ Lite.drfx" "$S/Templates/" 2>/dev/null
echo
echo "Done. Open DaVinci Resolve:"
echo "  Edit page: Effects > Titles > KINETIQ Lite Text."
echo "  Fusion page: Shift+Space > Kinetiq Lite."
read -r -p "Press Return to close." _
